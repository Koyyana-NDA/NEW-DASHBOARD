import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'

function DashboardPlaceholder() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <h1 className="text-3xl font-bold">Dashboard (Coming Soon)</h1>
    </div>
  )
}

export default function App() {
  const token = localStorage.getItem('token')
  return (
    <BrowserRouter>
      <Routes>
        {/* If no token, show Login; otherwise go to Dashboard */}
        <Route
          path="/"
          element={token ? <Navigate to="/dashboard" /> : <Login />}
        />
        {/* Protect Dashboard: only show if token */}
        <Route
          path="/dashboard"
          element={token ? <DashboardPlaceholder /> : <Navigate to="/" />}
        />
      </Routes>
    </BrowserRouter>
  )
}
