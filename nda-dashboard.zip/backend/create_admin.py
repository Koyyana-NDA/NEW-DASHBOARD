import sys
import os
sys.path.append(os.path.dirname(__file__))  # makes sure backend/ is in sys.path

from backend.models import User, UserRole
from backend.database import SessionLocal
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def create_admin():
    db = SessionLocal()
    hashed_password = pwd_context.hash("admin123")
    admin_user = User(
        username="admin",
        email="admin@example.com",
        hashed_password=hashed_password,
        role=UserRole.admin,
        is_admin=True
    )

    existing = db.query(User).filter_by(username="admin").first()
    if not existing:
        db.add(admin_user)
        db.commit()
        print("✅ Admin user created!")
    else:
        print("⚠️ Admin user already exists.")

if __name__ == "__main__":
    create_admin()
