from fastapi import FastAPI, Form, HTTPException, status, Depends
from sqlalchemy.orm import Session
from backend import models, auth, database

app = FastAPI()

# Create DB tables
models.Base.metadata.create_all(bind=database.engine)

@app.post("/token")
async def login(
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(database.SessionLocal)
):
    print("📥 Login attempt:", username)
    user = auth.authenticate_user(db, username, password)
    if not user:
        print("❌ Invalid login attempt")
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = auth.create_access_token(data={"sub": user.username})
    print("✅ Token generated:", token)
    return {"access_token": token, "token_type": "bearer"}
